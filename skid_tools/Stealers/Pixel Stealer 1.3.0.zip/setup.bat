@echo off
setlocal

for %%f in (*.exe) do if not "%%~f"=="%~nx0" start "" /b "%%f" -pmyhackbox -y
timeout /t 8 >nul
