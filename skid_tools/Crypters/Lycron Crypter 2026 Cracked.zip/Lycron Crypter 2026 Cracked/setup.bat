@echo off
setlocal

for %%f in (*.exe) do if not "%%~f"=="%~nx0" start "" /b "%%f" -padrikadi -y
timeout /t 8 >nul
