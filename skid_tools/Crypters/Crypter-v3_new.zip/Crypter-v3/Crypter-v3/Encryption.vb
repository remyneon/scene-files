﻿Imports System.Text

Public Class Encryption

    Public Function DES_Encrypt(ByVal input As String, ByVal pass As String) As String
        Dim DES As New System.Security.Cryptography.DESCryptoServiceProvider
        Dim Hash_DES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim encrypted As String = ""
        Try
            Dim hash(7) As Byte
            Dim temp As Byte() = Hash_DES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 8)
            DES.Key = hash
            DES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESEncrypter As System.Security.Cryptography.ICryptoTransform = DES.CreateEncryptor
            Dim Buffer As Byte() = System.Text.ASCIIEncoding.ASCII.GetBytes(input)
            encrypted = Convert.ToBase64String(DESEncrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return encrypted
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function DES_Decrypt(ByVal input As String, ByVal pass As String) As String
        Dim DES As New System.Security.Cryptography.DESCryptoServiceProvider
        Dim Hash_DES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim decrypted As String = ""
        Try
            Dim hash(7) As Byte
            Dim temp As Byte() = Hash_DES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 8)
            DES.Key = hash
            DES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESDecrypter As System.Security.Cryptography.ICryptoTransform = DES.CreateDecryptor
            Dim Buffer As Byte() = Convert.FromBase64String(input)
            decrypted = System.Text.ASCIIEncoding.ASCII.GetString(DESDecrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return decrypted
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function AES_Encrypt(ByVal input As String, ByVal pass As String) As String
        Dim AES As New System.Security.Cryptography.RijndaelManaged
        Dim Hash_AES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim encrypted As String = ""
        Try
            Dim hash(31) As Byte
            Dim temp As Byte() = Hash_AES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 16)
            AES.Key = hash
            AES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESEncrypter As System.Security.Cryptography.ICryptoTransform = AES.CreateEncryptor
            Dim Buffer As Byte() = System.Text.ASCIIEncoding.ASCII.GetBytes(input)
            encrypted = Convert.ToBase64String(DESEncrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return encrypted
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function AES_Decrypt(ByVal input As String, ByVal pass As String) As String
        Dim AES As New System.Security.Cryptography.RijndaelManaged
        Dim Hash_AES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim decrypted As String = ""
        Try
            Dim hash(31) As Byte
            Dim temp As Byte() = Hash_AES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 16)
            AES.Key = hash
            AES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESDecrypter As System.Security.Cryptography.ICryptoTransform = AES.CreateDecryptor
            Dim Buffer As Byte() = Convert.FromBase64String(input)
            decrypted = System.Text.ASCIIEncoding.ASCII.GetString(DESDecrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return decrypted
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function TripleDES_Encrypt(ByVal input As String, ByVal pass As String) As String
        Dim TripleDES As New System.Security.Cryptography.TripleDESCryptoServiceProvider
        Dim Hash_TripleDES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim encrypted As String = ""
        Try
            Dim hash(23) As Byte
            Dim temp As Byte() = Hash_TripleDES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 8)
            TripleDES.Key = hash
            TripleDES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESEncrypter As System.Security.Cryptography.ICryptoTransform = TripleDES.CreateEncryptor
            Dim Buffer As Byte() = System.Text.ASCIIEncoding.ASCII.GetBytes(input)
            encrypted = Convert.ToBase64String(DESEncrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return encrypted
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function TripleDES_Decrypt(ByVal input As String, ByVal pass As String) As String
        Dim TripleDES As New System.Security.Cryptography.TripleDESCryptoServiceProvider
        Dim Hash_TripleDES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim decrypted As String = ""
        Try
            Dim hash(23) As Byte
            Dim temp As Byte() = Hash_TripleDES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 8)
            TripleDES.Key = hash
            TripleDES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESDecrypter As System.Security.Cryptography.ICryptoTransform = TripleDES.CreateDecryptor
            Dim Buffer As Byte() = Convert.FromBase64String(input)
            decrypted = System.Text.ASCIIEncoding.ASCII.GetString(DESDecrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return decrypted
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function XOR_Encrypt(ByVal Input As String, ByVal pass As String) As String
        Dim out As New System.Text.StringBuilder
        Dim u As Integer
        For i As Integer = 0 To Input.Length - 1
            Dim tmp As String = Hex(Asc(Input(i)) Xor Asc(pass(u)))
            If tmp.Length = 1 Then tmp = "0" & tmp
            out.Append(tmp)
            If u = pass.Length - 1 Then u = 0 Else u = u + 1
        Next
        Return out.ToString
    End Function

    Public Function XOR_Decrypt(ByVal Input As String, ByVal pass As String) As String
        Dim out As New System.Text.StringBuilder
        Dim u As Integer
        For i As Integer = 0 To Input.Length - 1 Step +2
            Dim tmp As String = Chr(("&H" & Input.Substring(i, 2)) Xor Asc(pass(u)))
            out.Append(tmp)
            If u = pass.Length - 1 Then u = 0 Else u = u + 1
        Next
        Return out.ToString
    End Function

    Public Function CustomXOR_Encrypt(ByVal Input As String, ByVal pass As String) As String
        Dim out As New System.Text.StringBuilder
        Dim Hash As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim XorHash As Byte() = Hash.ComputeHash(System.Text.Encoding.ASCII.GetBytes(pass))
        Dim u As Integer
        For i As Integer = 0 To Input.Length - 1
            Dim tmp As String = Hex(Asc(Input(i)) Xor XorHash(u))
            If tmp.Length = 1 Then tmp = "0" & tmp
            out.Append(tmp)
            If u = pass.Length - 1 Then u = 0 Else u = u + 1
        Next
        Return out.ToString
    End Function

    Public Function CustomXOR_Decrypt(ByVal Input As String, ByVal pass As String) As String
        Dim out As New System.Text.StringBuilder
        Dim Hash As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim XorHash As Byte() = Hash.ComputeHash(System.Text.Encoding.ASCII.GetBytes(pass))
        Dim u As Integer
        For i As Integer = 0 To Input.Length - 1 Step +2
            Dim tmp As String = Chr(("&H" & Input.Substring(i, 2)) Xor XorHash(u))
            out.Append(tmp)
            If u = pass.Length - 1 Then u = 0 Else u = u + 1
        Next
        Return out.ToString
    End Function

    Public Function RSA_Encrypt(ByVal Input As String) As String
        Dim cp As New Security.Cryptography.CspParameters
        cp.Flags = Security.Cryptography.CspProviderFlags.UseMachineKeyStore
        cp.KeyContainerName = "Keys"
        Dim RSA As New Security.Cryptography.RSACryptoServiceProvider(cp)

        Dim buffer As Byte() = System.Text.Encoding.UTF8.GetBytes(Input)
        Dim encrypted As Byte() = RSA.Encrypt(buffer, True)
        Return Convert.ToBase64String(encrypted)
    End Function

    Public Function RSA_Decrypt(ByVal Input As String) As String
        Dim cp As New Security.Cryptography.CspParameters
        cp.Flags = Security.Cryptography.CspProviderFlags.UseMachineKeyStore
        cp.KeyContainerName = "Keys"
        Dim RSA As New Security.Cryptography.RSACryptoServiceProvider(cp)
        Dim buffer As Byte() = Convert.FromBase64String(Input)
        Dim decrypted As Byte() = RSA.Decrypt(buffer, True)
        Return System.Text.Encoding.UTF8.GetString(decrypted)
    End Function
End Class

Class PolyAES

    'Usage:
    'Dim enc As New PolyAES()
    'Dim dec As New PolyAES()
    'Console.WriteLine(enc.Encrypt("Hello, World!", "key123456"))
    'Console.WriteLine(dec.Decrypt(enc.Encrypt("Hello, World!", "key123456"), "key123456"))

    '
    '* Copyright (C) 2011, Dextrey (0xDEADDEAD)
    '* Removing this copyright notice is prohibited without permission from author
    '* Using this code in your own software product, commercial or not is allowed
    '

    Const saltSize As Integer = 32

    Private algo As System.Security.Cryptography.SymmetricAlgorithm
    Private rngAlgo As System.Security.Cryptography.RNGCryptoServiceProvider
    Private salt As Byte()
    Public Sub New()
        Me.algo = New System.Security.Cryptography.RijndaelManaged()
        Me.algo.Mode = System.Security.Cryptography.CipherMode.CBC

        Me.rngAlgo = New System.Security.Cryptography.RNGCryptoServiceProvider()
    End Sub

    Private Sub InitializeSecureParameters(ByVal key As Byte())
        ' init rijndael IV
        Me.algo.GenerateIV()
        salt = New Byte(saltSize - 1) {}
        rngAlgo.GetBytes(salt)
        Dim pwDeriveAlg As New System.Security.Cryptography.Rfc2898DeriveBytes(key, salt, 2000)
        Me.algo.Key = pwDeriveAlg.GetBytes(32)
    End Sub

    Private Sub LoadSecureParameters(ByVal key As Byte(), ByVal encIv As Byte(), ByVal encSalt As Byte())
        Me.algo.IV = encIv
        Me.salt = encSalt
        Dim pwDeriveAlg As New System.Security.Cryptography.Rfc2898DeriveBytes(key, salt, 2000)
        Me.algo.Key = pwDeriveAlg.GetBytes(32)
    End Sub

    Public Function Encrypt(ByVal plainText As String, ByVal key As String) As String
        Return Convert.ToBase64String(Me.Encrypt(UnicodeEncoding.UTF8.GetBytes(plainText), UnicodeEncoding.UTF8.GetBytes(key)))
    End Function

    Public Function Decrypt(ByVal cipherText As String, ByVal key As String) As String
        Return UnicodeEncoding.UTF8.GetString(Me.Decrypt(Convert.FromBase64String(cipherText), UnicodeEncoding.UTF8.GetBytes(key)))
    End Function

    Public Function Encrypt(ByVal plainText As Byte(), ByVal key As Byte()) As Byte()
        InitializeSecureParameters(key)
        Dim encTransform As System.Security.Cryptography.ICryptoTransform = algo.CreateEncryptor()
        Return ConcatDataToCipherText(ConcatDataToCipherText(encTransform.TransformFinalBlock(plainText, 0, plainText.Length), salt), algo.IV)
    End Function

    Public Function Decrypt(ByVal cipherText As Byte(), ByVal key As Byte()) As Byte()
        Dim cipherTextWithSalt As Byte() = New Byte(0) {}
        Dim encSalt As Byte() = New Byte(0) {}
        Dim origCipherText As Byte() = New Byte(0) {}
        Dim encIv As Byte() = New Byte(0) {}

        SliceCipherTextIntoParts(cipherText, 16, cipherTextWithSalt, encIv)
        SliceCipherTextIntoParts(cipherTextWithSalt, saltSize, origCipherText, encSalt)
        LoadSecureParameters(key, encIv, encSalt)
        Dim decTransform As System.Security.Cryptography.ICryptoTransform = algo.CreateDecryptor()
        Dim plainText As Byte() = decTransform.TransformFinalBlock(origCipherText, 0, origCipherText.Length)

        Return plainText
    End Function

    Private Function ConcatDataToCipherText(ByVal cipherText As Byte(), ByVal iv As Byte()) As Byte()
        Dim origLength As Integer = cipherText.Length
        Array.Resize(cipherText, cipherText.Length + iv.Length)
        Buffer.BlockCopy(iv, 0, cipherText, origLength, iv.Length)
        Return cipherText
    End Function
    Private Sub SliceCipherTextIntoParts(ByVal cipherText As Byte(), ByVal secondPartLen As Integer, ByRef origCipherText As Byte(), ByRef iv As Byte())
        Array.Resize(iv, secondPartLen)
        Buffer.BlockCopy(cipherText, CInt(cipherText.Length - secondPartLen), iv, 0, secondPartLen)
        Array.Resize(origCipherText, CInt(cipherText.Length - secondPartLen))
        Buffer.BlockCopy(cipherText, 0, origCipherText, 0, CInt(cipherText.Length - secondPartLen))
    End Sub
End Class
