<?php
/*
Plugin Name: PayPal File Download
Description: PayPal File Download lets you easily sell your files online with PayPal. PayPal File Download automatically delivers a file to a user, with integrated, transparent, and full-featured IPN, email delivery, link expiry, customer information capture, and more.
Version: 2.0.1
Author: Mark Bao / YesPlugins
License: GPL2
 */

/*
 * PayPal File Download 2.0.1
 * by YesPlugins, a division of The Bao Group, LLC.
 * (c) 2010 - 2012 The Bao Group, LLC. All rights reserved.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

// Standalone
PayPalFileDownload::init();

// Renku
// add_action('sputnik_loaded', array('PayPalFileDownload', 'renku_verify'));
// add_action('all_admin_notices', array('PayPalFileDownload', 'renku_report_error'));

class PayPalFileDownload {
  protected static $currencies = array(
    'USD' => array('United States Dollar','$'),
    'AUD' => array('Australian Dollar','AUD$'), 
    'BRL' => array('Brazilian Real','R$'),
    'GBP' => array('British Pound','&pound;'),
    'CAD' => array('Canadian Dollar','CAD$'),
    'CNY' => array('Chinese Yuan','&#20803;'),
    'DKK' => array('Danish Krone','kr.'),
    'EUR' => array('European Euro','&#8364;'),
    'HKD' => array('Hong Kong Dollar','HK$'),
    'HUF' => array('Hungarian Forint','Ft'),
    'INR' => array('Indian Rupee','INR'),
    'IDR' => array('Indonesian Rupiah','Rp'),
    'JPY' => array('Japanese Yen','&yen;'),
    'MXN' => array('Mexican Peso','MEX$'),
    'NZD' => array('New Zealand Dollar','NZ$'),
    'NOK' => array('Norwegian Kroner','kr'),
    'PLN' => array('Polish Zloty','zl.'),
    'RUB' => array('Russian Ruble','RUB'),
    'SAR' => array('Saudi Riyal','SR'),
    'SGD' => array('Singapore Dollar','SGD$'),
    'ZAR' => array('South African Rand','R'),
    'SEK' => array('Swedish Krona','kr'),
    'CHF' => array('Swiss Franc','CHF'),
    'THB' => array('Thai Bhat','&#3647;'),
    'TRY' => array('Turkish Lira','TRY'),
    'TWD' => array('Taiwan Dollar','TWD')
  );

  const VERSION = '2.0.1';
  const DB_VERSION = '2.0';

  public static function init() {
    register_activation_hook(__FILE__, array(__CLASS__, 'install'));

    // admin stuff
    add_action('admin_menu', array(__CLASS__, 'admin_menu'));
    add_action('admin_init', array(__CLASS__, 'admin_init'));

    // ajax
    add_action('wp_ajax_paypal-file-download-generate', array(__CLASS__, 'admin_generate'));
    add_action('wp_ajax_paypal-file-download-resend-email', array(__CLASS__, 'admin_resend_email'));

    // media buttons hook
    add_action('media_buttons_context', array(__CLASS__, 'media_button'));

    // insert form
    add_action('admin_footer', array(__CLASS__, 'add_pfd_form'));
    
    // shortcode
    add_shortcode('pfd', array(__CLASS__, 'shortcode_pfd'));

    // listener for ipn activation
    add_action('template_redirect', array(__CLASS__, 'var_listener'));
    add_filter('query_vars', array(__CLASS__, 'register_vars'));
    
    add_action('admin_menu', array(__CLASS__, 'add_meta_box'));
    
    // anonymous usage
    self::anonymous_usage();
  }

  protected static function transactioncode($length = "") {
    $code = md5(uniqid(rand(), true));
    if ($length != "") return strtoupper(substr($code, 0, $length));
    else return strtoupper($code);
  }
 
  protected static function relative_time($ptime) {
    $etime = time() - $ptime;

    if ($etime < 1) {
      return '0 seconds';
    }

    $a = array( 12 * 30 * 24 * 60 * 60  =>  'year',
          30 * 24 * 60 * 60       =>  'month',
          24 * 60 * 60            =>  'day',
          60 * 60                 =>  'hour',
          60                      =>  'minute',
          1                       =>  'second'
          );

    foreach ($a as $secs => $str) {
      $d = $etime / $secs;
      if ($d >= 1) {
        $r = round($d);
        return $r . ' ' . $str . ($r > 1 ? 's' : '');
      }
    }
  }

  // Renku verification and bootstrap
  public static function renku_verify() {
    remove_action('all_admin_notices', array('PayPalFileDownload', 'renku_report_error'));
    Sputnik::check(__FILE__, array('PayPalFileDownload', 'init'));
  }
  
  // Renku error reporter
  public static function renku_report_error() {
    echo '<div class="error"><p>Please install &amp; activate Renku to enable PayPal File Download.</p></div>';
  }
  
  public static function add_meta_box() {
    add_meta_box( 'pfd_sectionid', "PayPal File Download", array(__CLASS__, 'meta_box'), 'post', 'side', 'high' );
    add_meta_box( 'pfd_sectionid', "PayPal File Download", array(__CLASS__, 'meta_box'), 'page', 'side', 'high' );
    
    // support for custom post types
    $custom_post_types = get_post_types( array( '_builtin' => false ) );
    if (is_array($custom_post_types) && !empty($custom_post_types)) {
      foreach( $custom_post_types as $post_type ) {
        $post_type = trim( $post_type );
        add_meta_box( 'pfd_sectionid', "PayPal File Download", array(__CLASS__, 'meta_box'), $post_type, 'side', 'high' );
      }
    }
  }
  
  public static function meta_box() {
//    echo '<div style="margin-top:5px;margin-bottom:5px;">';
    echo '<a href="#TB_inline?width=450&inlineId=paypal_file_download_form" class="thickbox button" title="Insert PayPal Checkout Link">Insert PayPal Buy Button/Link</a>';
//    echo '</div>';
  }

  public static function install() {
    global $wpdb;
    
    $message_default = <<<EOT
Hi [FIRST_NAME] [LAST_NAME],

Thank you for your purchase of [PRODUCT_NAME]! Your download link is included at the bottom of this message. For future reference, your transaction ID is [TRANSACTION_ID].

Thank you, and enjoy!
EOT;

    $message_default_nofile = <<<EOT
Hi [FIRST_NAME] [LAST_NAME],

Thank you for your purchase of [PRODUCT_NAME]! For future reference, your transaction ID is [TRANSACTION_ID].

Thank you, and enjoy!
EOT;

    // set default options - but don't override if they're already set
    add_option("email_message", $message_default, '','yes');
    add_option("email_message_nofile", $message_default_nofile, '','yes');
    add_option("expire_links_after", 7, '','yes');
    add_option("paypal_email", "test@replaceme.com", '','yes');
    add_option("paypal_return_url", get_option("home"), '','yes');
    add_option("pfd_usage", "1");
    add_option("pfd_email_from_name", get_option('blogname'));
    add_option("pfd_email_from_email", get_option('admin_email'));

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $table_name = $wpdb->prefix . "pfd_products";
    $sql = "CREATE TABLE " . $table_name . " (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      name VARCHAR(255) NOT NULL,
      file VARCHAR(255) NOT NULL,
      downloads bigint(11) NOT NULL,
      cost decimal(11,2) NOT NULL,
      created_at bigint(11) DEFAULT '0' NOT NULL,
      PRIMARY KEY id (id)
    );";
    dbDelta($sql);
    
    $table_name = $wpdb->prefix . "pfd_orders";
    $sql = "CREATE TABLE " . $table_name . " (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      product_id mediumint(9) NOT NULL,
      order_code VARCHAR(255) NOT NULL,
      fulfilled mediumint(9) NOT NULL,
      cost decimal(11,2) NOT NULL,
      created_at bigint(11) DEFAULT '0' NOT NULL,
      PRIMARY KEY id (id)
    );";
    dbDelta($sql);
    
    $table_name = $wpdb->prefix . "pfd_transactions";
    $sql = "CREATE TABLE " . $table_name . " (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      product_id mediumint(9) NOT NULL,
      order_id mediumint(9) NOT NULL,
      order_code VARCHAR(255) NOT NULL,
      protection_eligibility VARCHAR(255) NULL,
      address_status VARCHAR(255) NULL,
      payer_id VARCHAR(255) NULL,
      tax decimal(11,2) NULL,
      payment_date VARCHAR(255) NULL,
      payment_status VARCHAR(255) NULL,
      first_name VARCHAR(255) NULL,
      last_name VARCHAR(255) NULL,
      payer_status VARCHAR(255) NULL,
      business VARCHAR(255) NULL,
      address_name VARCHAR(255) NULL,
      address_street VARCHAR(255) NULL,
      address_city VARCHAR(255) NULL,
      address_state VARCHAR(255) NULL,
      address_zip VARCHAR(255) NULL,
      address_country_code VARCHAR(255) NULL,
      address_country VARCHAR(255) NULL,
      quantity VARCHAR(255) NULL,
      verify_sign VARCHAR(255) NULL,
      payer_email VARCHAR(255) NULL,
      txn_id VARCHAR(255) NULL,
      payment_type VARCHAR(255) NULL,
      receiver_email VARCHAR(255) NULL,
      receiver_id VARCHAR(255) NULL,
      txn_type VARCHAR(255) NULL,
      item_name VARCHAR(255) NULL,
      mc_currency VARCHAR(255) NULL,
      item_number VARCHAR(255) NULL,
      residence_country VARCHAR(255) NULL,
      custom VARCHAR(255) NULL,
      receipt_id VARCHAR(255) NULL,
      transaction_subject VARCHAR(255) NULL,
      payment_fee decimal(11,2) NOT NULL,
      payment_gross decimal(11,2) NOT NULL,
      created_at bigint(11) DEFAULT '0' NOT NULL,
      PRIMARY KEY id (id)
    );";
    dbDelta($sql);

    $table_name = $wpdb->prefix . "pfd_ipn_messages";
    $sql = "CREATE TABLE " . $table_name . " (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      ipn_message TEXT NULL,
      created_at bigint(11) DEFAULT '0' NOT NULL,
      PRIMARY KEY id (id)
    );";
    dbDelta($sql);
    
    // if we are running an older version,
    // make sure we note it down before we update the DB version
    if (get_option("pfd_db_version") == "1.0") {
      // old version - enable legacy queries
      // and mark an installation made pre-2.0
      update_option("pfd_legacy_query", "1");
      update_option("pfd_pre2", "1");

      // disable usage statistics reporting
      update_option("pfd_usage", "0");
    }

    update_option("pfd_db_version", self::DB_VERSION);
  }

  protected static function get_currency() {
    if (get_option('pfd_currency')) {
      $cc = get_option('pfd_currency');
    } else {
      $cc = "USD";
    }
    
    return $cc;
  }

  protected static function get_currency_symbol() {
    $cc = self::get_currency();
    
    return self::$currencies[$cc][1];
  }

  public static function validate_currency($currency) {
    if (!empty(self::$currencies[$currency]))
      return $currency;
    return 'USD';
  }

  public static function admin_init() {
    register_setting('pfd_options', 'email_message');
    register_setting('pfd_options', 'email_message_nofile');
    register_setting('pfd_options', 'expire_links_after', 'intval');
    register_setting('pfd_options', 'paypal_email');
    register_setting('pfd_options', 'paypal_return_url');
    register_setting('pfd_options', 'pfd_usage');
    register_setting('pfd_options', 'pfd_currency', array(__CLASS__, 'validate_currency'));
    register_setting('pfd_options', 'pfd_download_method');
    register_setting('pfd_options', 'pfd_email_from_name');
    register_setting('pfd_options', 'pfd_email_from_email');
  }

  public static function admin_menu() {
    add_menu_page( "PayPal File Download", "PayPal File Download", 'manage_options', 'paypal-file-download', array(__CLASS__, 'admin_dashboard'), plugins_url('menu_icon.png', __FILE__));

    add_submenu_page( 'paypal-file-download', "PayPal File Download Products", "Products", 'manage_options', "paypal-file-download-products", array(__CLASS__, 'admin_products_router'));

    add_submenu_page( 'paypal-file-download', "PayPal File Download Settings", "Settings", 'manage_options', "paypal-file-download-settings", array(__CLASS__, 'admin_settings'));

    add_submenu_page( 'paypal-file-download', "PayPal File Download Transactions", "Transactions", 'manage_options', "paypal-file-download-transactions", array(__CLASS__,'admin_transactions'));

    global $submenu;
  }

  public static function admin_products_router() {
    $action = '';
    if (!empty($_REQUEST['action'])) {
      $action = $_REQUEST['action'];
    }
    
    switch ($action) {
      case 'edit':
        return self::admin_products_edit();
        break;
      case 'delete':
        return self::admin_products_delete();
        break;
      case 'add':
        return self::admin_products_add();
        break;
      case 'ipnlog':
        return self::admin_ipnlog();
        break;
      default:
        return self::admin_products();
    }
  }

  protected static function admin_products_edit() {
    
    global $wpdb;
    $table_name = $wpdb->prefix . "pfd_products";
    
    if (isset($_POST["product_name"])) {
    
      $name = $_POST["product_name"];
      $url = $_POST["product_url"];
      $cost = $_POST["product_cost"];
      
      $wpdb->update( $table_name, array('name' => $name, 'file' => $url, 'cost' => $cost), array('id' => $_GET["id"]), array( '%s', '%s', '%s'));
    }
    
    $product = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d",$_GET["id"]) , ARRAY_A, 0);
  ?>
  <div class="wrap">
    <?php wp_enqueue_script("jquery"); ?>
    <?php wp_enqueue_script("thickbox"); ?>
    <?php wp_enqueue_style('thickbox.css', '/'.WPINC.'/js/thickbox/thickbox.css', null, '1.0'); ?>
    <?php wp_enqueue_script('media-upload'); ?>
    <script type="text/javascript">
    if ( typeof tb_pathToImage != 'string' ) {
        var tb_pathToImage = "<?php echo get_bloginfo('url').'/wp-includes/js/thickbox'; ?>/loadingAnimation.gif";
    }

    if ( typeof tb_closeImage != 'string' ) {
        var tb_closeImage = "<?php echo get_bloginfo('url').'/wp-includes/js/thickbox'; ?>/tb-close.png";
    }
    </script>
    <script type="text/javascript">
    jQuery(document).ready(function() {
      jQuery('#upload_file_button').click(function() {
        formfield = jQuery('#upload_image').attr('name');
        tb_show('','media-upload.php?type=file&amp;TB_iframe=true');
        return false;
      });

      // send url back to plugin editor
      window.send_to_editor = function(html) {
        var fileurl = jQuery(html).attr('href');
        jQuery('#product_url').val(fileurl);
        tb_remove();
      }
    });
    </script>
    <h2>Edit Product: <?php echo $product['name'] ?></h2>
    <a href="<?php echo admin_url('admin.php?page=paypal-file-download-products'); ?>">&laquo; Back to Products</a>
    <form action="<?php echo admin_url('admin.php?page=paypal-file-download-products&action=edit&id=' . $_GET['id']); ?>" method="post">
    <table class="form-table">
      <tr valign="top">
        <th scope="row">Product Name</th>
        <td><input type="text" name="product_name" style="width:250px;" value="<?php echo str_replace('"','\"',$product["name"]); ?>" /></td>
      </tr>
      <tr valign="top">
        <th scope="row">URL of Product</th>
        <td><input type="text" name="product_url" id="product_url" style="width:400px;" value="<?php echo str_replace('"','\"',$product["file"]); ?>" /><br />This is the source URL of your product. Make sure that it is non-guessable.<br />You can enter the URL of an already-uploaded file here, or <input id="upload_file_button" value="Upload" type="button" />.</td>
      </tr>
      <tr valign="top">
        <th scope="row">Cost Per Download</th>
        <td><?php echo self::get_currency_symbol() ?><input type="text" name="product_cost" style="width:50px;" value="<?php echo str_replace('"','\"',$product["cost"]); ?>" /></td>
      </tr>
      <tr valign="top">
        <th scope="row">&nbsp;</th>
        <td>
          <div><input type="submit" class="button-primary" value="Save Product" /></div>
          <div style="margin-top: 15px; padding-left: 5px;"><a href="<?php echo admin_url('admin.php?page=paypal-file-download-products&action=delete&id=' . $product['id']); ?>" onclick="if(confirm('Are you sure you want to delete this product? There is NO UNDO!')) { return true; } else { return false; }">Delete Product</a></div>
        </td>
      </tr>
    </table>
    </form>
  </div>
  <?php
  }

  protected static function admin_products_delete() {
    // delete and redirect
    global $wpdb;
    $table_name = $wpdb->prefix . "pfd_products";
    
    $id = $_GET["id"];
    
    $wpdb->query("DELETE FROM $table_name WHERE id = '$id'");
    ?>
    <script type="text/javascript">
    <!--
    window.location = "<?php echo admin_url('admin.php?page=paypal-file-download-products'); ?>"
    //-->
    </script>
    <?php
  }

  public static function admin_dashboard() {
    if (!current_user_can('manage_options'))  {
      wp_die( __('You do not have sufficient permissions to access this page.') );
    }
    
  ?>  
  <?php
  }

  protected static function admin_products() {
    if (!current_user_can('manage_options'))  {
      wp_die( __('You do not have sufficient permissions to access this page.') );
    }
?>
  <?php wp_enqueue_script("jquery"); ?>
  <?php wp_enqueue_script("thickbox"); ?>
  <?php wp_enqueue_style('thickbox.css', '/'.WPINC.'/js/thickbox/thickbox.css', null, '1.0'); ?>
  <?php wp_enqueue_script('media-upload'); ?>
  <script type="text/javascript">
  if ( typeof tb_pathToImage != 'string' ) {
    var tb_pathToImage = "<?php echo get_bloginfo('url').'/wp-includes/js/thickbox'; ?>/loadingAnimation.gif";
  }

  if ( typeof tb_closeImage != 'string' ) {
    var tb_closeImage = "<?php echo get_bloginfo('url').'/wp-includes/js/thickbox'; ?>/tb-close.png";
  }
  </script>
  <style type="text/css">
    @import url(<?php echo plugins_url( 'assets/font/font-awesome.css' , __FILE__ ); ?>);

    .pfd_sep {
      padding-left: 5px;
      padding-right: 5px;
    }

    .widefat td {
      padding-top: 10px;
      padding-bottom: 10px;
      vertical-align: middle;
    }

    .pfd_product_name {
      font-size: 11pt !important;
    }

    .pfd_product {
      display: block;
      width: 200px;
      height: 300px;
      padding: 15px 0 0 0;
      margin-right: 15px;
      margin-bottom: 15px;
      background-color: #eee;
      float: left;
      position: relative;
      -webkit-border-radius: 5px;
      -moz-border-radius: 5px;
      border-radius: 5px;
    }

    .pfd_product h2 {
      font: bold 14pt/18pt '' !important;
      padding: 0 15px;
    }

    .pfd_product .pfd_actions {
      position: absolute;
      bottom: 0;
      width: 200px;
    }

    .pfd_product .pfd_actions:hover ul li .pfd_action_info, .pfd_product .pfd_actions:hover ul li a {
      color: #111;
    }

    .pfd_product .pfd_actions ul {
      margin: 0;
      list-style: none;
    }

    .pfd_product .pfd_actions ul li {
      margin: 0;
      padding: 0;
      border-top: 1px solid #dfdfdf;
    }

    .pfd_product .pfd_actions ul li a, .pfd_product .pfd_actions ul li .pfd_action_info {
      display: block;
      color: #999999;
      text-decoration: none;
      padding: 10px 15px;
      -webkit-transition: color .375s ease;
    }

    .pfd_product .pfd_actions ul li:last-child a {
      -webkit-border-bottom-left-radius: 5px;
      -moz-border-radius-bottomleft: 5px;
      border-bottom-left-radius: 5px;
      -webkit-border-bottom-right-radius: 5px;
      -moz-border-radius-bottomright: 5px;
      border-bottom-right-radius: 5px;
    }
    
    .pfd_product .pfd_actions ul li a i, .pfd_product .pfd_actions ul li .pfd_action_info i {
      font-size: 12pt;
      vertical-align: -1px;
    }

    .pfd_product .pfd_actions ul li a:hover {
      background-color: #ddd;
    }
    
    a#pfd_add_product_button {
      display: block;
      width: 160px;
      height: 20px;
      padding-top: 12px;
      padding-bottom: 10px;
      margin-bottom: 20px;
      margin-top: 10px;
      background-color: #44AA55;
      color: #FFFFFF;
      font-size: 13pt;
      text-align: center;
      text-decoration: none;
      -webkit-border-radius: 4px;
      -moz-border-radius: 4px;
      border-radius: 4px;
    }
    
    a#pfd_add_product_button i {
      vertical-align: -1px;
    }

    a#pfd_add_product_button:hover {
      background-color: #368A44;
    }
    
    a#pfd_add_product_button:active {
      background-color: #317D3D;
      padding-top: 13px;
      height: 19px;
    }

    #pfd_add_product_form {
      display: none;
      width: 600px;
      padding: 15px;
      background-color: #EEEEEE;
      -webkit-border-radius: 5px;
      -moz-border-radius: 5px;
      border-radius: 5px;
      margin-bottom: 20px;
      margin-top: 10px;
    }
    
    #pfd_add_product_form h3 {
      padding: 0 0 10px 0;
      margin: 0;
    }

    #pfd_add_product_form th, #pfd_add_product_form td {
      padding: 5px 0 0 0;
      margin: 0;
    }
    
    #TB_window {
      height: 170px !important;
    }

    #TB_window input.url {
      width: 100%;
      border: 0;
      padding: 0;
      outline: 0;
      margin: 0;
    }
  </style>
  <script type="text/javascript">
    toggleAdd = function() {
      jQuery("#pfd_add_product_button").toggle();
      jQuery("#pfd_add_product_form").toggle();
    };

    jQuery(document).ready(function() {
      jQuery('#upload_file_button').click(function() {
        formfield = jQuery('#upload_image').attr('name');
        tb_show('','media-upload.php?type=file&amp;TB_iframe=true');
        return false;
      });

      // send url back to plugin editor
      window.send_to_editor = function(html) {
        var fileurl = jQuery(html).attr('href');
        jQuery('#product_url').val(fileurl);
        tb_remove();
      }
    });
  </script>
  <div class="wrap">
    <h2><i class="icon-tags"></i> Products</h2>
        <a id="pfd_add_product_button" href="#" onclick="toggleAdd();"><i class="icon-plus-sign"></i> Add a product</a>
        <div id="pfd_add_product_form">
          <h3>Add a Product</h3>
          <form action="<?php echo admin_url('admin.php?page=paypal-file-download-products&action=add'); ?>" method="post">
            <table class="form-table">
              <tr valign="top">
                <th scope="row">Product Name</th>
                <td><input type="text" name="product_name" style="width:250px;" value="" /></td>
              </tr>
              <tr valign="top">
                <th scope="row">Source URL of Product</th>
                <td><input type="text" id="product_url" name="product_url" style="width:400px;" value="" /><br />This is the source URL of your product. Make sure that it is non-guessable.<br />You can enter the URL of an already-uploaded file here, or <input id="upload_file_button" value="Upload" type="button" />.</td>
              </tr>
              <tr valign="top">
                <th scope="row">Cost Per Download</th>
                <td><?php echo self::get_currency_symbol(); ?><input type="text" name="product_cost" style="width:50px;" value="" /></td>
              </tr>
              <tr valign="top">
                <th scope="row">&nbsp;</th>
                <td>
                  <input type="submit" class="button-primary" value="Add Product" />
                </td>
              </tr>
            </table>
          </form>
        </div>
        <?php
        global $wpdb;
        $table_name = $wpdb->prefix . "pfd_products";
        $products = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY id ASC" ,ARRAY_A);
        if (count($products) == 0) {
        ?>
          No products. Click the button above to create one!
        <?php
        } else {
        foreach ($products as $product) {
        ?>
        <div class="pfd_product">
          <h2 class="pfd_product_name"><?php echo $product["name"]; ?></h2>
          <div class="pfd_actions">
            <ul>
              <li><div class="pfd_action_info"><i class="icon-tag"></i> <?php echo self::get_currency_symbol(); ?><?php echo $product['cost'] ?> &mdash; <i class="icon-download-alt"></i> <?php echo $product['downloads'] ?></div></li>
              <li><a href="<?php echo admin_url('admin.php?page=paypal-file-download-products&action=edit&id=' . $product['id']); ?>"><i class="icon-pencil"></i> Edit Product</a></li>
              <li><a href="#TB_inline?height=100&width=300&inlineId=pfd_product_checkout-<?php echo $product['id']; ?>" class="thickbox"><i class="icon-shopping-cart"></i> Get Purchase Link</a></li>
              <li><a href="<?php echo admin_url('admin-ajax.php?action=paypal-file-download-generate&product_id=' . $product['id']); ?>&height=220&width=400" class="thickbox"><i class="icon-bookmark"></i> Generate Download Link</a></li>
            </ul>
            <div id="pfd_product_checkout-<?php echo $product['id']; ?>" style="display: none;">
              <div style="margin-top: 20px; margin-bottom: 10px;"><h3>Checkout link for <?php echo $product['name']; ?></h3></div>
              <div><input type="text" class="url" value="<?php echo get_option('home'); ?>/?pfd_checkout=<?php echo $product['id'] ?>"  onclick="this.select();" /></div>
              <div style="margin-top: 20px; margin-bottom: 5px;"><strong>Shortcode option to put in a post/page</strong></div>
              <div><input type="text" class="url" value='[pfd product="<?php echo $product['id'] ?>" image="https://www.paypal.com/en_US/i/btn/btn_buynowCC_LG.gif"]' onclick="this.select();" /></div>
            </div>
          </div>
        </div>
        <?php } } ?>

    <div style="clear: both;"></div>
    
  </div>
  <?php
  }


  static function admin_generate() { 
    if (!current_user_can('manage_options'))  {
      wp_die( __('You do not have sufficient permissions to access this page.') );
    }

    global $wpdb;

    $product_id = intval($_REQUEST["product_id"]);
    
    // get product
    $table_name = $wpdb->prefix . "pfd_products";
    $product = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d",$product_id) , ARRAY_A, 0);

    // create order
    $table_name = $wpdb->prefix . "pfd_orders";
    $t_code = self::transactioncode(22);
    $wpdb->insert( $table_name, array('product_id' => $product_id, 'order_code' => $t_code, 'fulfilled' => 1, 'created_at' => time(), 'cost' => $product["cost"]), array( '%d', '%s', '%d', '%d', '%s') );

    // get the order
    $order = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE order_code = %d",$t_code) , ARRAY_A, 0);

    // assign current user
    $current_user = wp_get_current_user();

    $trans["product_id"] = $product_id;
    $trans["order_code"] = $t_code;
    $trans["order_id"] = $order["id"];
    $trans["protection_eligibility"] = "";
    $trans["address_status"] = "";
    $trans["payer_id"] = "Generated";
    $trans["tax"] = 0;
    $trans["payment_date"] = "Generated";
    $trans["payment_status"] = "";
    $trans["first_name"] = "Generated";
    $trans["last_name"] = "Download";
    $trans["payer_status"] = "";
    $trans["business"] = get_option("paypal_email");
    $trans["address_name"] = "Generated Download";
    $trans["address_street"] = "Generated by " . $current_user->display_name . " (" . $current_user->user_email . ")";
    $trans["address_city"] = "None";
    $trans["address_state"] = "NA";
    $trans["address_zip"] = "";
    $trans["address_country_code"] = "";
    $trans["address_country"] = "";
    $trans["quantity"] = "1";
    $trans["verify_sign"] = "";
    $trans["payer_email"] = get_option("paypal_email");
    $trans["txn_id"] = "Generated";
    $trans["payment_type"] = "generated";
    $trans["receiver_email"] = get_option("paypal_email");
    $trans["receiver_id"] = "";
    $trans["txn_type"] = "generated";
    $trans["item_name"] = $product["name"];
    $trans["mc_currency"] = "";
    $trans["item_number"] = "Generated";
    $trans["residence_country"] = "";
    $trans["custom"] = "";
    $trans["receipt_id"] = "";
    $trans["transaction_subject"] = $product["name"];
    $trans["payment_fee"] = "0.00";
    $trans["payment_gross"] = "0.00";
    $trans["created_at"] = time();
    
    // insert into transactions
    $table_name = $wpdb->prefix . "pfd_transactions";
    $wpdb->insert($table_name, $trans);

    // return transaction ID
    echo '<div>';
    echo '<div style="margin-top: 20px; margin-bottom: 10px;"><h3>Generated download link for ' . $product['name'] . '. <span style="font-weight: normal;">This link is for direct download without payment.</span></h3></div>';
    echo '<div><input type="text" class="url" value="' . get_option('home') . '/?pfd_download=' . $trans["order_code"] . '" onclick="this.select();" /></div>';
    echo '</div>';
    exit();
  }

  protected static function admin_products_add() {
    // get details
    $name = $_POST["product_name"];
    $url = $_POST["product_url"];
    $cost = $_POST["product_cost"];

    // ensure http:// in URL
    if (strpos($url, 'http') === false) {
      // add http://
      $url = "http://" . $url;
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . "pfd_products";
    
    $wpdb->insert( $table_name, array('name' => $name, 'file' => $url, 'cost' => $cost, 'downloads' => 0, 'created_at' => time()), array( '%s', '%s', '%s', '%d', '%d') );
    
    ?>
    <script type="text/javascript">
    <!--
    window.location = "<?php echo admin_url('admin.php?page=paypal-file-download-products'); ?>"
    //-->
    </script>
    <?php
  }

  protected static function admin_ipnlog() {
    
    global $wpdb;
    $table_name = $wpdb->prefix . "pfd_ipn_messages";
    $product = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d",$_GET["id"]) , ARRAY_A, 0);
    $ipnlogs = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC" ,ARRAY_A);
  ?>
  <div class="wrap">
    <h2>IPN Log</h2>
    <table class="form-table">
      <?php foreach ($ipnlogs as $ipnlog) { ?>
      <tr valign="top">
        <th scope="row"><?php echo $ipnlog["created_at"]; ?><br /><?php echo strftime("%c", $ipnlog["created_at"]); ?></th>
        <td><textarea rows="7" cols="70"><?php echo $ipnlog["ipn_message"]; ?></textarea></td>
      </tr>
      <?php } ?>
    </table>
    </form>
  </div>
  <?php
  }


  public static function admin_settings() {
    if (!current_user_can('manage_options'))  {
      wp_die( __('You do not have sufficient permissions to access this page.') );
    }
  ?>
  <style type="text/css">
    @import url(<?php echo plugins_url( 'assets/font/font-awesome.css' , __FILE__ ); ?>);
  </style>
  <div class="wrap">
    <h2><i class="icon-cogs"></i> PayPal File Download Settings</h2>
    <?php
        if (isset($_GET['settings-updated'])) {
          echo '<div id="message" class="updated"><p>Updated settings!</p></div>';
        }
    ?>
    <form method="post" action="options.php">
      <?php settings_fields('pfd_options'); ?>
      <table class="form-table">
        <tr valign="top">
          <th scope="row"><strong>PayPal email</strong></th>
          <td><input type="text" name="paypal_email" style="width:300px;" value="<?php echo get_option('paypal_email'); ?>" /><br />This is the email transactions will post to. Make sure you have subscribed to PayPal Website Payments Standard.</td>
        </tr>
        <tr valign="top">
          <th scope="row"><strong>Expire links after...</strong></th>
          <td><input type="text" name="expire_links_after" style="width:50px;" value="<?php echo get_option('expire_links_after'); ?>" /> days (0 for no expiry)<br />Activating this will expire download links after a certain amount of time.</td>
        </tr>
        <tr valign="top">
          <th scope="row"><strong>Return URL</strong></th>
          <td><input type="text" name="paypal_return_url" style="width:250px;" value="<?php echo get_option('paypal_return_url'); ?>" /><br />This should be a URL (a page, preferably) on your site that says that the transaction has been completed and details (and download link) have been emailed to them.</td>
        </tr>
        <tr valign="top">
          <th scope="row"><strong>Currency</strong></th>
          <?php
            $cc = self::get_currency();
          ?>
          <td>
            <select name="pfd_currency">
              <?php foreach(self::$currencies as $ccode => $currency) { ?>
              <option value="<?php echo $ccode; ?>" <?php if ($ccode == $cc) { ?>selected="selected"<?php } ?>><?php echo $currency[0]; ?> (<?php echo $currency[1]; ?>)</option>
              <?php } ?>
            </select>
            <br />Select the currency that your products will be sold in.</td>
        </tr>
        <tr valign="top">
          <th scope="row"><strong>From Name/Email</strong></th>
          <td><label><input type="text" name="pfd_email_from_name" style="width:140px;" value="<?php echo get_option('pfd_email_from_name'); ?>" /></label> <label style="margin-left: 10px;"><input type="text" name="pfd_email_from_email" style="width:250px;" value="<?php echo get_option('pfd_email_from_email'); ?>" /></label><br />The name and email for <em>from</em> field of the receipt and download email.</td>
        </tr>
        <tr valign="top">
          <th scope="row"><strong>Email message</strong></th>
          <td><textarea name="email_message" style="width:400px;height:200px;"><?php echo get_option('email_message'); ?></textarea><br />This will be what your customer receives after they pay.<br /><strong>The download link is automatically placed at the bottom of the message.</strong><br />You can use the following variables: [FIRST_NAME] [LAST_NAME] [DOWNLOAD_LINK] [PRODUCT_NAME] [TRANSACTION_ID]<br />Remember, your server must be set up to send mail.</td>
        </tr>
        <tr valign="top">
          <th scope="row"><strong>Anonymous usage</strong></th>
          <td><input type="checkbox" name="pfd_usage" value="1" <?php if (get_option('pfd_usage') == 1) { ?>checked="checked"<?php } ?> /> Send anonymous usage statistics to YesPlugins to help us improve this product.<br />Only sends a download number. Absolutely no customer data, product data, website URLs, or any other identifiable information is sent.</td>
        </tr>
        <tr valign="top">
          <th scope="row"><strong>Download method</strong><br />(Advanced)</th>
          <td>
            <div>
              <select name="pfd_download_method">
                <?php $current_method = get_option("pfd_download_method"); ?>
                <?php
                $dl_methods = array();
                $dl_methods["wp_remote"] = "WordPress Remote (Default)";
                $dl_methods["direct"] = "Direct download (Works with all servers)";
                $dl_methods["streaming_fopen"] = "Streaming (Best for large files)";
                $dl_methods["streaming_curl"] = "Streaming cURL (Experimental)";
                $dl_methods["file_get_contents"] = "file_get_contents";
                $dl_methods["curl"] = "PHP/cURL";
                ?>
                <?php foreach ($dl_methods as $method_id => $method_name) { ?>
                <option value="<?php echo $method_id; ?>" <?php if ($method_id == $current_method) { ?>selected="selected"<?php } ?>><?php echo $method_name; ?></option>
                <?php } ?>
              </select>
            </div>
            <div>Select the download method for serving the file to the customer.</div>
          </td>
        </tr>
        <tr valign="top">
          <th scope="row">&nbsp;</th>
          <td>
            <input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
          </td>
        </tr>
      </table>
    </form>
  </div>
  <?php
  }

  public static function admin_transactions() {
    if (!current_user_can('manage_options'))  {
      wp_die( __('You do not have sufficient permissions to access this page.') );
    }
  ?>
  <?php wp_enqueue_script("jquery"); ?>
  <?php wp_enqueue_script("thickbox"); ?>
  <?php wp_enqueue_style('thickbox.css', '/'.WPINC.'/js/thickbox/thickbox.css', null, '1.0'); ?>
  <script type="text/javascript">
  if ( typeof tb_pathToImage != 'string' ) {
    var tb_pathToImage = "<?php echo get_bloginfo('url').'/wp-includes/js/thickbox'; ?>/loadingAnimation.gif";
  }

  if ( typeof tb_closeImage != 'string' ) {
    var tb_closeImage = "<?php echo get_bloginfo('url').'/wp-includes/js/thickbox'; ?>/tb-close.png";
  }
  </script>
  <style type="text/css">
    @import url(<?php echo plugins_url( 'assets/font/font-awesome.css' , __FILE__ ); ?>);

    .pfd_transaction_main_box .pfd_transaction_actions, .pfd_transaction_main_box .pfd_transaction_actions a {
      color: #999999;
    }

    .pfd_transaction_row:hover .pfd_transaction_actions {
      color: #333333;
    }

    .pfd_transaction_row:hover .pfd_transaction_actions a {
      color: #21759B;
    }

    #TB_window {
      height: 120px !important;
    }

    #TB_window input.url {
      width: 100%;
      border: 0;
      padding: 0;
      outline: 0;
      margin: 0;
    }
  </style>
  <div class="wrap">
    <h2><i class="icon-list-alt"></i> Transactions</h2>
    <table class="widefat post fixed" cellspacing="0">
      <thead>
        <tr>
          <th scope="col" id="name" width="15%" class="manage-column" style="">Name &amp; Email</th>
          <th scope="col" id="name" width="30%" class="manage-column" style="">Transaction ID, Product</th>
          <th scope="col" id="name" width="20%" class="manage-column" style="">Date</th>
          <th scope="col" id="cost" width="6%" class="manage-column" style="">Cost</th>
          <th scope="col" id="address" width="15%" class="manage-column" style="">Address</th>
          <th scope="col" id="fee" class="manage-column" style="">PayPal Fee</th>
          <th scope="col" id="earnings" class="manage-column" style="">Earnings</th>
        </tr>
      </thead>

      <tfoot>
        <tr>
          <th scope="col" id="name" width="15%" class="manage-column" style="">Name &amp; Email</th>
          <th scope="col" id="name" width="30%" class="manage-column" style="">Transaction ID, Product</th>
          <th scope="col" id="name" width="20%" class="manage-column" style="">Date</th>
          <th scope="col" id="cost" width="6%" class="manage-column" style="">Cost</th>
          <th scope="col" id="address" width="15%" class="manage-column" style="">Address</th>
          <th scope="col" id="fee" class="manage-column" style="">PayPal Fee</th>
          <th scope="col" id="earnings" class="manage-column" style="">Earnings</th>
        </tr>
      </tfoot>

      <tbody>
        <?php
        global $wpdb;
        $table_name = $wpdb->prefix . "pfd_transactions";
        $products_name = $wpdb->prefix . "pfd_products";
        $orders_name = $wpdb->prefix . "pfd_orders";
        
        $transactions = $wpdb->get_results( "SELECT $table_name.order_code, $products_name.name, $table_name.first_name, $table_name.created_at, $table_name.last_name, $table_name.address_street, $table_name.address_city, $table_name.address_state, $table_name.address_zip, $table_name.address_country, $table_name.payment_fee, $table_name.payer_email, $orders_name.cost FROM $table_name JOIN $products_name ON $table_name.product_id = $products_name.id JOIN $orders_name ON $table_name.order_id = $orders_name.id ORDER BY $table_name.id DESC" ,ARRAY_A);
        
        if (count($transactions) == 0) {
        ?>
        <tr class='alternate author-self status-publish iedit' valign="top">
          <td class="" colspan="7">No transactions yet.</td>
        </tr>
        <?php
        } else {
        foreach ($transactions as $transaction) {
        ?>
        <tr class='alternate author-self status-publish iedit pfd_transaction_row' valign="top">
          <td class=""><?php echo $transaction['first_name'] ?> <?php echo $transaction['last_name'] ?><br /><?php echo $transaction['payer_email'] ?></td>
          <td class="post-title column-title pfd_transaction_main_box">
            <div><?php echo $transaction['order_code'] ?></div>
            <div><strong><?php echo $transaction['name'] ?></strong></div>
            <div class="pfd_transaction_actions"><a href="#TB_inline?height=100&width=300&inlineId=pfd_transaction_dlink-<?php echo $transaction['order_code']; ?>" class="thickbox">Copy download link</a> &middot; <a href="<?php echo admin_url('admin-ajax.php?action=paypal-file-download-resend-email&transaction_id=' . $transaction['order_code'] . '&height=220&width=400'); ?>" class="thickbox">Resend email</a></div>
          </td>
          <td class=""><?php echo strftime("%a, %B %e, %Y %r", $transaction['created_at']) ?><br />(<?php echo self::relative_time($transaction["created_at"]) ?> ago)</td>
          <td class="">$<?php echo $transaction['cost'] ?></td>
          <td class=""><?php echo $transaction['address_street'] ?><br /><?php echo $transaction['address_city'] ?>, <?php echo $transaction['address_state'] ?> <?php echo $transaction['address_zip'] ?><br /><?php echo $transaction['address_country'] ?></td>
          <td class="">$<?php echo $transaction['payment_fee'] ?></td>
          <td class="">$<?php if ($transaction['first_name'] == "Generated") { echo "0.00"; } else { ?><?php echo $transaction['cost'] - $transaction['payment_fee'] ?><?php } ?></td>
          <div id="pfd_transaction_dlink-<?php echo $transaction['order_code']; ?>" style="display: none;">
            <div style="margin-top: 20px; margin-bottom: 10px;"><h3>Download link for <?php echo $transaction['first_name'] . ' ' . $transaction['last_name']; ?></h3></div>
            <div><input type="text" class="url" value="<?php echo get_option('home'); ?>/?pfd_download=<?php echo $transaction['order_code'] ?>"  onclick="this.select();" /></div>
          </div>
        </tr>
        
        <?php } } ?>
      </tbody>
    </table>
  </div>
  <?php
  }

  public static function admin_resend_email() {
    if (!current_user_can('manage_options'))  {
      wp_die( __('You do not have sufficient permissions to access this page.') );
    }

    global $wpdb;

    $transaction_id = $_REQUEST["transaction_id"];
    
    // get product
    $table_name = $wpdb->prefix . "pfd_transactions";
    $transaction = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE order_code = %s",$transaction_id) , ARRAY_A, 0);

    // download link
    $download_link = get_option('home') . "/?pfd_download=" . $transaction_id;
    
    $details = array();
    $details["email"] = $transaction["payer_email"];
    $details["first_name"] = $transaction["first_name"];
    $details["last_name"] = $transaction["last_name"];
    $details["download_link"] = $download_link;
    $details["product_name"] = $transaction["item_name"];
    $details["transaction_id"] = $transaction_id;
    
    self::send_email($details);

    echo '<div>';
    echo '<div style="margin-top: 20px; margin-bottom: 10px;"><h3>Resend receipt/download email</h3></div>';
    echo '<div>Receipt/download email resent to <strong>' . $details["email"] . '</strong>.';
    echo '</div>';

    exit();
  }

  public static function media_button($context){
    $image_url = plugins_url('media_icon.png', __FILE__);
    $more = '<a href="#TB_inline?width=450&inlineId=paypal_file_download_form" class="thickbox" title="Insert PayPal Checkout Link"><img src="' . $image_url . '" alt="Insert PayPal Checkout Link" /></a>';
    return $context . $more;
  }

  public static function add_pfd_form() {
  ?>
  <script type="text/javascript">
    function insert_pfd_button(){
      product_id = jQuery("#product_selector").val()
      image = jQuery("#button_image_url").val()
      
      construct = '<a href="<?php echo get_option('home') ?>/?pfd_checkout=' + product_id + '"><img src="' + image + '" /></a>';
      
      var wdw = window.dialogArguments || opener || parent || top;
      wdw.send_to_editor(construct);
    }

    function insert_pfd_link(){
      product_id = jQuery("#product_selector").val()
      
      construct = '<a href="<?php echo get_option('home') ?>/?pfd_checkout=' + product_id + '"><?php echo get_option('home') ?>/?pfd_checkout=' + product_id + '</a>';
      
      var wdw = window.dialogArguments || opener || parent || top;
      wdw.send_to_editor(construct);
    }
  </script>

  <div id="paypal_file_download_form" style="display:none;">
    <div class="wrap">
      <div>
        <div style="padding:15px 15px 0 15px;">
          <h3 style="font-size:16pt !important;line-height:1em !important;color:#555555 !important; font-family: Helvetica Neue, Helvetica, Arial, sans-serif !important; line-height: 1.3em !important; margin-bottom: 10px;"><span style="font-weight:normal; ">PayPal File Download</span><br />Insert Checkout Button/Link</h3>
          <span>Choose one of your products below to insert a download link to your page or post.</span>
        </div>
        <div style="padding:15px 15px 0 15px;">
          <table width="100%">
            <tr>
              <td width="135"><strong>Product</strong></td>
              <td>
                <select id="product_selector">
                  <?php
                  global $wpdb;
                  $table_name = $wpdb->prefix . "pfd_products";
                  $products = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY id ASC;" ,ARRAY_A);
                  if (count($products) == 0) {
                  ?>
                  No products available. <a href="<?php echo admin_url('admin.php?page=paypal-file-download-products'); ?>">Save your post, then click here to add some.</a>
                  <?php
                  } else {
                    foreach($products as $product) {
                  ?>
                      <option value="<?php echo $product["id"] ?>"><?php echo $product["name"] ?> ($<?php echo $product["cost"] ?>)</option>
                  <?php
                  }
                  }
                  ?>
                </select>
              </td>
            </tr>
            <tr>
              <td width="135"><strong>Button Image URL</strong></td>
              <td><input type="text" id="button_image_url" value="https://www.paypal.com/en_US/i/btn/btn_buynowCC_LG.gif" style="width:220px;" /></td>
            </tr>
          </table>
        </div>
        
        <div style="padding:15px;">
          <input type="button" class="button-primary" value="Insert Button" onclick="insert_pfd_button();"/>&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" class="button" value="Insert Link Only" onclick="insert_pfd_link();"/>&nbsp;&nbsp;&nbsp;&nbsp;<a style="font-size:0.9em;text-decoration:none;color:#555555;" href="#" onclick="tb_remove(); return false;">Cancel and Close</a>
        </div>
      </div>
    </div>
  </div>
  <?php
  }

  static function get_download_method() {
    $available_methods = array("wp_remote", "direct", "streaming_fopen", "streaming_curl", "file_get_contents", "curl");

    if (get_option('pfd_download_method') == NULL || get_option('pfd_download_method') == '') {
      return "wp_remote";
    } else {
      $download_method = get_option('pfd_download_method');
      if (in_array($download_method, $available_methods)) {
        return $download_method;
      } else {
        // invalid method
        return "wp_remote"; 
      }
    }
  }

  protected static function ipn() {
    echo "-- PayPal File Download / version " . self::VERSION . "\n";
    echo "-- (c) 2012 YesPlugins, a division of The Bao Group.\n";
    echo "-- beginning ipn\n";

    global $wpdb;
    
    // save POST data
    $post_data_string = http_build_query($_POST);
    $table_name = $wpdb->prefix . "pfd_ipn_messages";
    $wpdb->insert( $table_name, array('ipn_message' => $post_data_string, 'created_at' => time()), array( '%s', '%d') );

    // check for debugf
    $debugf = false;
    if (isset($_POST["debugf"])) {
      $debugf = true;
      unset($_POST["debugf"]);
    }

    require_once('paypal.class.php');

    $p = new paypal_class;
    $p->paypal_url = 'https://www.paypal.com/cgi-bin/webscr';
    
    $this_script = get_option('home');
    
    echo "-- ipn validating...\n";
    
    if ($p->validate_ipn()) {
      echo "-- ipn validated\n";
      // find with order id
      $table_name = $wpdb->prefix . "pfd_orders";
      
      $order = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE order_code = %s", $_POST["item_number"]) , ARRAY_A, 0);
      
      echo "-- found order\n";

      // check fulfillment status
      $order_fulfilled = intval($order['fulfilled']);
      if ($order_fulfilled !== 0 && $debugf === false) {
        die('Order already fufilled.');
      } else {
        // set ipn_cost to check against
        $ipn_cost = $_POST["mc_gross"];
        
        // check for tax
        if (isset($_POST["tax"])) {
          if ($_POST["tax"] != "0.00") {
            $ipn_cost_big = (int) ($ipn_cost * 100);
            $tax_big = (int) ($_POST["tax"] * 100);
            $real_cost_big = $ipn_cost_big - $tax_big;
            $real_cost_big = $real_cost_big * 0.01;
            $ipn_cost = number_format($real_cost_big, 2, '.', '');
          }
        }
        
        if ((string) $order["cost"] == $ipn_cost) {
          // good
          echo "-- OK: costs match\n";
        } else {
          echo "-- NO: costs do not match. abort.\n";
          die("Error. Costs do not match.");
          // todo: send email
        }
        
        $wpdb->update( $table_name, array('fulfilled' => 1), array('id' => $order["id"]));
        
        echo "-- order marked as fulfilled\n";
        
        $table_name = $wpdb->prefix . "pfd_products";
        $product = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d",$order["product_id"]) , ARRAY_A, 0);
        
        $wpdb->update( $table_name, array('downloads' => $product["downloads"] + 1), array('id' => $product["id"]));
        
        $trans = array();
        
        // vars we want to extract
        $fields = "protection_eligibility address_status payer_id tax payment_date payment_status first_name last_name payer_status business address_name address_street address_city address_state address_zip address_country_code address_country quantity verify_sign payer_email txn_id payment_type receiver_email receiver_id txn_type item_name mc_currency item_number residence_country custom receipt_id transaction_subject payment_fee payment_gross";
        
        $fields_a = explode(" ",$fields);
        
        foreach($fields_a as $field) {
          $trans[$field] = isset($_POST[$field]) ? $_POST[$field] : NULL;
        }
        
        $trans["product_id"] = $product["id"];
        $trans["order_code"] = $order["order_code"];
        $trans["order_id"] = $order["id"];
        $trans["created_at"] = time();
        
        // insert into transactions
        $table_name = $wpdb->prefix . "pfd_transactions";
        $wpdb->insert($table_name, $trans);
        
        echo "-- transaction executed\n";
        
        echo "-- preparing email\n";
        
        // download link
        $download_link = get_option('home') . "/?pfd_download=" . $_POST["item_number"];
        
        $details = array();
        $details["email"] = $_POST["payer_email"];
        $details["first_name"] = $_POST["first_name"];
        $details["last_name"] = $_POST["last_name"];
        $details["download_link"] = $download_link;
        $details["product_name"] = $product["name"];
        $details["transaction_id"] = $_POST["item_number"];
        
        self::send_email($details);
        
        echo "-- email sent to " . $to . "\n";
      }
    }
  }

  public static function send_email($details) {
    // get email text
    $emailtext = get_option('email_message');
    $emailtext = str_replace("[FIRST_NAME]", $details["first_name"], $emailtext);
    $emailtext = str_replace("[LAST_NAME]", $details["last_name"], $emailtext);
    $emailtext = str_replace("[DOWNLOAD_LINK]", $details["download_link"], $emailtext);
    $emailtext = str_replace("[PRODUCT_NAME]", $details["product_name"], $emailtext);
    $emailtext = str_replace("[TRANSACTION_ID]",$details["transaction_id"], $emailtext);
    
    $emailtext = $emailtext . "\n\nYou can download your file here:\n" . $details["download_link"];
    
    // fantastic, now send them a message
    $to      = $details["email"];
    
    $subject = "Receipt and Download for your purchase of " . $details["product_name"];
    $message = $emailtext;
    
    $headers = 'From: '. get_option('pfd_email_from_name') .' <' . get_option('pfd_email_from_email') . '>' . "\r\n Reply-To: " . get_option('pfd_email_from_name') . ' <' . get_option('pfd_email_from_email') . '>' . "\r\n X-Mailer: PayPalFileDownload";
    
    wp_mail($to, $subject, $message, $headers);
  }

  public static function var_listener() {
    // 3 vars to listen for
    // - pfd_action
    // - pfd_checkout (checkout in legacy)
    // - pfd_download (download in legacy)

    if (get_query_var("pfd_action") == "ipn") {
      // IPN activated
      self::ipn();

      // don't execute wp
      exit();
    }

    if (get_query_var("pfd_checkout") != NULL || (get_option('pfd_legacy_query') == 1 && get_query_var("checkout") != NULL)) {
      // get ID
      if (get_query_var("checkout") != NULL) {
        $product_id = get_query_var("checkout");
      } else {
        $product_id = get_query_var("pfd_checkout");
      }

      
      global $wpdb;
      $table_name = $wpdb->prefix . "pfd_products";
      
      // get product
      $product = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d",$product_id) , ARRAY_A, 0);
      
      // construct order
      $table_name = $wpdb->prefix . "pfd_orders";
      
      $t_code = self::transactioncode(22);
      
      $wpdb->insert( $table_name, array('product_id' => $product_id, 'order_code' => $t_code, 'fulfilled' => 0, 'created_at' => time(), 'cost' => $product["cost"]), array( '%d', '%s', '%d', '%d', '%s') );
      
      $ccode = self::get_currency();
      
      // get url for paypal
      $paypal_url = "https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=" . get_option('paypal_email') . "&item_name=" . urlencode($product["name"]) . "&item_number=" . $t_code . "&amount=" . urlencode($product["cost"]) . "&currency_code=" . $ccode . "&shipping=0&notify_url=" . urlencode(get_option('home') . "/?pfd_action=ipn");
      
      $paypal_url = $paypal_url . "&return=" . urlencode(get_option('paypal_return_url'));
      
      header('Location: ' . $paypal_url);
      
      exit; // don't execute wp
    }

    if (get_query_var("pfd_download") != NULL || (get_option('pfd_legacy_query') == 1 && get_query_var("download") != NULL)) {
      // download
      // get ID
      if (get_query_var("download") != NULL) {
        $id = get_query_var("download");
      } else {
        $id = get_query_var("pfd_download");
      }
      
      global $wpdb;

      $table_name = $wpdb->prefix . "pfd_transactions";
      $transaction = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE order_code = %s",$id ), ARRAY_A, 0);
      
      if ($transaction==NULL) {
        die("File not found.");
      } else {
        $table_name = $wpdb->prefix . "pfd_products";
        $product = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d",$transaction["product_id"]), ARRAY_A, 0);
        
        // get option for days
        $daysexpire = get_option('expire_links_after');
        if ($daysexpire == 0) {
          // don't check
        } else {
          // check for expiry
          // transaction created at should be larger than now - x days
          $nowminus = time() - ($daysexpire*86400);
          if ($transaction["created_at"] > $nowminus) {
            // good
          } else {
            die("Sorry, your download has expired.");
          }
        }
        
        // get download method
        $download_method = self::get_download_method();
        
        switch ($download_method) {
          case "wp_remote":
            // force download
            $result = wp_remote_get($product["file"], array("method" => "GET", "timeout" => 15));

            if (get_class($result) == "WP_Error") {
              echo "An error occured when downloading this file. Please contact the seller with the following information:<br /><hr /><br />PayPal File Download error occurred. Error: ";
              print_r($result);
              echo "<br /><br />This usually happens because your server configuration is not set up to serve large files. Before you contact support, please refer to the following documentation and change your Download Method in Settings: http://yesplugins.com/jump/help-wperror";
            } else {
              header('Content-disposition: attachment; filename=' . basename($product["file"]));
              header('Content-Type: application/octet-stream');
              header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
              header('Expires: 0');
              echo $result['body'];
            }

            die();
            break;
          case "direct":
            // redirect the user to the right place
            header('Location: ' . $product["file"]);
            break;
          case "streaming_fopen":
            // force download
            header('Content-disposition: attachment; filename=' . basename($product["file"]));
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Expires: 0');
            header("Content-Type: application/download");
            header("Content-Description: File Transfer");            
            flush();
            
            // stream the file
            $fp = fopen($product["file"], "r");
            while (!feof($fp)) {
              echo fread($fp, 65536);
              flush(); // this is essential for large downloads
            }
            fclose($fp); 
            
            die();

            break;
          case "streaming_curl":
            header('Content-disposition: attachment; filename=' . basename($product["file"]));
            header('Content-Type: application/octet-stream');
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Expires: 0');
            stream_wrapper_register("pfdstream", "PayPalFileDownloadStream") or die("Failed to register protocol");
            $fp = fopen("pfdstream://MemoryVar", "r+");
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $product["file"]);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_BUFFERSIZE, 256);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FILE, $fp);    // Data will be sent to our stream ;-)
            curl_exec($ch);
            curl_close($ch);
            fclose($fp);
            die();
            break;
          case "file_get_contents":
            header('Content-disposition: attachment; filename=' . basename($product["file"]));
            header('Content-Type: application/octet-stream');
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Expires: 0');
            $result = file_get_contents($product["file"]);
            echo $result;
            die();
            break;
          case "curl":
            header('Content-disposition: attachment; filename=' . basename($product["file"]));
            header('Content-Type: application/octet-stream');
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Expires: 0');
            $ch = curl_init();
            $timeout = 0; // set to zero for no timeout
            curl_setopt($ch, CURLOPT_URL, $product["file"]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            $file_contents = curl_exec($ch);
            curl_close($ch);

            echo $file_contents;
            die();
            break;
          default:
            die("No download method selected. Please contact the seller with the contents of this error message.");
            break;
        }
      }
    }
  }

  // make sure we have the paypal action listener available
  public static function register_vars($vars) {
    $vars[] = "pfd_action";
    $vars[] = "pfd_checkout";
    $vars[] = "pfd_download";

    // legacy mode
    if (get_option("pfd_legacy_query") == 1) {
      $vars[] = "checkout";
      $vars[] = "download";
    }

    return $vars; // return to wordpress
  }
  
  public static function shortcode_pfd($atts) {
    if ($atts['image']) {
      $image = $atts['image'];
    } else {
      $image = "https://www.paypal.com/en_US/i/btn/btn_buynowCC_LG.gif";
    }

    return '<a href="' . get_option('home') . '/?pfd_checkout=' . $atts["product"] . '"><img src="' . $image . '" alt="Checkout with PayPal" /></a>';
  }

  protected static function anonymous_usage() {
    if (get_option('pfd_usage') == 1) {
      $usage_id = get_option('pfd_usage_id');
      $last_collection = get_option('pfd_last_usage');
      $last_collection_downloads = get_option('pfd_last_usage_downloads');
      
      $difference = time() - intval($last_collection);

      if ($last_collection == NULL || $difference > 86400) {
        update_option('pfd_last_usage', time());

        global $wpdb;
        $table_name = $wpdb->prefix . "pfd_products";
        $products = $wpdb->get_results("SELECT downloads FROM $table_name ORDER BY id ASC", ARRAY_A);
        
        $dlcount = 0;

        if (count($products) != 0) {
          foreach ($products as $product) {
            $dlcount = $dlcount + intval($product['downloads']);
          }
          
          if ($last_collection_downloads == NULL) {
            $last_collection_downloads = 0;
          } else {
            $last_collection_downloads = intval($last_collection_downloads);
          }

          if ($dlcount > $last_collection_downloads) {
            update_option('pfd_last_usage_downloads', $dlcount);

            $dl_difference = $dlcount - $last_collection_downloads;
            
            if ($usage_id == NULL) {
              $usage_id = self::transactioncode(); // random anonymous identifier
              update_option('pfd_usage_id', $usage_id);
            }

            return true;
          }
        }
      }
    }
  }
}

class PayPalFileDownloadStream {
  protected $buffer;

  function stream_open($path, $mode, $options, &$opened_path) {
    return true;
  }

  public function stream_write($data) {
    echo $data;
    return strlen($data);
  }
}
